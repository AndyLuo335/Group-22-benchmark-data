## Starting kit

The zipped folder called ``baselines.zip`` contains the two baseline models as well as the public datasets.